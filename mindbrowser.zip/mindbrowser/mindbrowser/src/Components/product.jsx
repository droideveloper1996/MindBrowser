import React, { Component } from "react";
import CheckoutComponent from "./checkout";
import { Link } from "react-router-dom";
import axios from "axios";
class ProductComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  makePayment = async () => {
    console.log("makePayment Called");
    const paymentParams = {
      MID: "MERCHANT_ID_MUST_BE_CHANGED", // paytm provide
      WEBSITE: "DEFAULT", // paytm provide
      INDUSTRY_TYPE_ID: "Retail", // paytm provide
      CHANNEL_ID: "WEB", // paytm provide
      ORDER_ID: `ORDER-${Date.now()}`, // unique id
      CUST_ID: "787112734994837", // customer id
      MOBILE_NO: "8604681087", // customer mobile number
      EMAIL: "kushwaha.27@gmail.com", // customer email
      TXN_AMOUNT: "1", // transaction amount
      CALLBACK_URL: "http://localhost:3300/callback", // Call back URL that i want to redirect after payment fail or success
    };
    const result = await axios.post(
      "http://localhost:3300/checksum",
      paymentParams
    );
    const _data = await result.data;
    console.log(_data);
    this.initiatePayment({ ...paymentParams, CHECKSUMHASH: _data });
  };

  initiatePayment = async (paytm, checksum) => {
    console.log("Checksum generated");
    const my_form = document.createElement("form");
    my_form.name = "f1";
    my_form.method = "post";
    my_form.action = "https://securegw.paytm.in/order/process";
    const myParams = Object.keys(paytm);
    const myParamsVal = Object.values(paytm);
    console.log(myParams);
    for (let i = 0; i < myParams.length; i++) {
      const key = myParams[i];
      let my_tb = document.createElement("input");
      my_tb.type = "hidden";
      my_tb.name = key;
      my_tb.value = myParamsVal[i];
      my_form.appendChild(my_tb);
    }

    console.log(my_form);
    document.body.appendChild(my_form);
    my_form.submit();
  };

  render() {
    return (
      <div className="main">
        <div className="card">
          <img src={this.props.img} width="40%" />
          <div className="container">
            <h4>
              <button
                className="btn btn-sucess"
                onClick={() => this.makePayment()}
              >
                Buy Now
              </button>
            </h4>
            <h4>
              <b>{this.props.name}</b>
            </h4>
            <p>{this.props.desc}</p>
          </div>
        </div>
      </div>
    );
  }
}

export default ProductComponent;
