import logo from "./logo.svg";
import "./App.css";
import checkout from "./Components/checkout";
import CheckoutComponent from "./Components/checkout";
import StoreContext from "./store/storeContext";
import ConfigureAppStore from "./store/store";
import HomeComponent from "./Components/home";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
const store = ConfigureAppStore();
function App() {
  return (
    <StoreContext.Provider value={store}>
      <Router>
        <Switch>
          <Route path="/" exact={true} component={HomeComponent} />
          <Route path="/checkout" exact={true} component={CheckoutComponent} />
        </Switch>
      </Router>
    </StoreContext.Provider>
  );
}

export default App;
