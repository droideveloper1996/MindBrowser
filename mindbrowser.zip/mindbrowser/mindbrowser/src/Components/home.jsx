import React, { Component } from "react";
import { addItem } from "../store/cart";
import ConfigureAppStore from "../store/store";
import StoreContext from "../store/storeContext";
import ProductComponent from "./product";

class HomeComponent extends Component {
  items = ConfigureAppStore().getState();
  constructor(props) {
    super(props);

    this.state = {};
  }
  componentDidMount = () => {
    ConfigureAppStore().dispatch(
      addItem({ name: "iPhnne 11", quantity: 12, id: 7 })
    );
    setTimeout(() => {
      ConfigureAppStore().dispatch(
        addItem({ name: "iPhone 12", quantity: 22, id: 8 })
      );
    }, 3000);
  };

  addItems = () => {
    ConfigureAppStore().dispatch(
      addItem({ name: "iPhnne 13", quantity: 1, id: 9 })
    );
  };
  addItems2 = () => {
    ConfigureAppStore().dispatch(
      addItem({ name: "iPhnne 14", quantity: 12, id: 10 })
    );
  };
  render() {
    return (
      <div>
        <h1>My Cart</h1>
        {this.items.map((product) => {
          return (
            <ProductComponent
              img={product.img}
              name={product.title}
              desc={product.desc}
              price={product.price}
            />
          );
        })}
      </div>
    );
  }
}

HomeComponent.contextType = StoreContext;

export default HomeComponent;
