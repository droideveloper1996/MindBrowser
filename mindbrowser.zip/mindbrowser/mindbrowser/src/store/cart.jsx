import { createAction } from "@reduxjs/toolkit";
import { createReducer } from "@reduxjs/toolkit";

export const addItem = createAction("addItems");
export const removeItem = createAction("removeItem");

const initState = {
  items: [
    {
      id: 1,
      title: "Apple iPhone 11",
      desc: "iPhone 11 Technical Specifications · Liquid Retina HD display · 15.5 cm / 6.1‑inch (diagonal) all-screen LCD Multi-Touch display with IPS technology · 1792x828‑ ",
      price: 1,
      img: "https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/refurb-iphone-11-pro-gold-2019?wid=2000&hei=2000&fmt=jpeg&qlt=80&.v=1611101491000",
    },
    {
      id: 2,
      title: "MacBook Pro",
      desc: "New Apple Macbook pro M1 Chip",
      price: 1,
      img: "https://photos5.appleinsider.com/gallery/45023-87560-000-lead-14-inch-MacBook-Pro-xl.jpg",
    },
    {
      id: 3,
      title: "Apple iPad Pro",
      desc: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, ex.",
      price: 1,
      img: "https://m.media-amazon.com/images/I/61DsXT1ldtL._AC_SY450_.jpg",
    },
    {
      id: 4,
      title: "Apple Airpod Pro",
      desc: "Apple airpods pro",
      price: 1,
      img: "https://www.apple.com/v/airpods-pro/c/images/meta/og__ch3csr9zmviq_overview.png",
    },
  ],
  addedItems: [],
  total: 0,
};

const cartReducer = createReducer(initState.items, {
  addItems: (state, action) => {
    state.push({
      id: action.payload.id,
      title: action.payload.name,
      desc: "This is some description",
      price: 20,
      quantity: action.payload.quantity,
    });
  },
  //   [removeItem.type]: (state, action) => {},
});
export default cartReducer;
