import { configureStore } from "@reduxjs/toolkit";
//reducer required
import cartReducer from "./cart";

const ConfigureAppStore = () => configureStore({ reducer: cartReducer });
export default ConfigureAppStore;
